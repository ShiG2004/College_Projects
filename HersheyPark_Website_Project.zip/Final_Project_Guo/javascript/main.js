function hersheyPark() {
    alert("The front door of the fun! Hershey Park! The Hersheypark front door welcomes visitors with a grand entrance and a promise of sweet adventures.");
}

function ferrisWheel() {
    alert("This is a picture of the Furry Wheel in Hershey Park! The Hersheypark Ferris Wheel provides a bird's-eye view of the park, offering a breathtaking panorama of the attractions.");
}

function rollerCoaster() {
    alert("Hybird Roller Coaster! H*ll Yeah! The Wildcat's Revenge offers a thrilling hybrid roller coaster experience with its unique blend of wooden and steel track.");
}

function tripleTower() {
    alert("The Hersheypark Triple Tower was a thrilling ride with three separate towers, each offering a different level of intensity.");
}

function waterPark() {
    alert("The Hersheypark Water Park is a refreshing escape on a hot summer day, offering a variety of water slides, pools, and lazy rivers.");
}

function zooAmerica() {
    alert("The Hersheypark Zoo America offers a fun and educational experience, showcasing a variety of North American animals.");
}

function hersheyWorld() {
    alert("Hersheypark's Hershey's Chocolate World offers a sweet adventure, showcasing the history of chocolate and providing opportunities to sample delicious treats.");
}

function hersheyStore() {
    alert("The Hersheypark Hershey Chocolate Store offers a wide variety of delicious chocolate treats, from classic Hershey's bars to unique seasonal confections.");
}